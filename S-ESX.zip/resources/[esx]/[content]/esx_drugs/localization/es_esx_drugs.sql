USE `es_extended`;

INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
	('cannabis', 'Marijuana húmeda', 3, 0, 1),
	('marijuana', 'Marijuana', 2, 0, 1)
;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('weed_processing', 'permiso de cultivo de Marijuana')
;
