Locales['fr'] = {
  ['new_job'] = 'vous avez un nouveau job !',
  ['access_job_center'] = 'appuyez sur ~INPUT_PICKUP~ pour \naccéder au ~b~Pôle Emploi~s~.',
  ['job_center'] = 'pôle-Emploi',
}
