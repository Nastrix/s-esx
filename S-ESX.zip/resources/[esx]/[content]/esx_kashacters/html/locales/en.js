const translate = new Object();

translate.name = "Name";
translate.job = "Job";
translate.bank = "Bank";
translate.money = "Cash";
translate.gender = "Gender";
translate.dob = "Date of birth";
translate.new = "";
translate.delete = "DELETE";
translate.play = "PLAY";
translate.playNew = "CREATE CHARACTER";
translate.modalTitle = "Are You Sure?";
translate.modalText = "By deleting your account we won't be able to recover it, all properties, cars etc. will be deleted";