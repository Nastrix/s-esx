const translate = new Object();

translate.name = "imię";
translate.job = "Zajęcie";
translate.bank = "Bank";
translate.money = "Gotówka";
translate.gender = "Seks";
translate.dob = "Data urodzenia";
translate.new = "Utwórz nową postać";
translate.delete = "KASOWAĆ";
translate.play = "GRAĆ";
translate.playNew = "TWORZYĆ POSTAĆ";
translate.modalTitle = "Jesteś pewny?";
translate.modalText = "Po usunięciu konta nie będziemy mogli go odzyskać, wszystkie nieruchomości, samochody itp. Zostaną usunięte";