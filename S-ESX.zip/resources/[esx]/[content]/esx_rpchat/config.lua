Config = {}

Config.Locale = 'en'
Config.OnlyFirstname = false
Config.EnableESXIdentity = true -- only turn this on if you are using esx_identity and want to use RP names
