---
id: 13
name: 'supportBigNumbers'
---
When dealing with big numbers (BIGINT and DECIMAL columns) in the database, you should enable this option (Default: `false`).