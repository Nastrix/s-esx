---
id: 14
---

#### Database Options

Included in the table are the benchmark results of 1,000,000 inserts, with 20 done per server tick, that should mean it is about 100 inserts per second.
